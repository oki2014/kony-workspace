function AS_Button_ia986f39503c4de88ab1b53eee699c9e(eventobject) {
    var dataGrid = FormDataGrid.dataGrid1;
    var data = [{
        loginId: "mytext",
        username: "user",
        password: "pass"
    }];
    dataGrid.addAll(data);
}