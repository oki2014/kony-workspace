function skinsInit() {
    CopyslFbox0f21cc804770742 = "CopyslFbox0f21cc804770742";
    slButtonGlossBlue = "slButtonGlossBlue";
    slButtonGlossRed = "slButtonGlossRed";
    slDataGridAltRow = "slDataGridAltRow";
    slDataGridFocusedRow = "slDataGridFocusedRow";
    slDataGridHead = "slDataGridHead";
    slDataGridRow = "slDataGridRow";
    slDynamicNotificationForm = "slDynamicNotificationForm";
    slFbox = "slFbox";
    slForm = "slForm";
    slPopup = "slPopup";
    slStaticNotificationForm = "slStaticNotificationForm";
    slTextArea = "slTextArea";
    slTextBox = "slTextBox";
    slTitleBar = "slTitleBar";
    slWatchForm = "slWatchForm";
};